// JavaScript Document
function checkAnswer() {
    
    var poeng = 0; 
    var a1 = document.getElementById("q1"); 

    if (a1.value === "1977") {
        alert("Du har rett svar på nr 1");
        poeng = poeng + 1;
		}
	
	var poeng = 0; 
    var a2 = document.getElementById("q2"); 

    if (a2.value === "det er våpenet til en jedi") {
        alert("Du har rett svar på nr 2");
        poeng = poeng + 1;
		}

	
	var poeng = 0; 
    var a3 = document.getElementById("q3"); 

    if (a3.value === "1999") {
        alert("Du har rett svar på nr 3");
        poeng = poeng + 1;
		}
	
	var poeng = 0;
	var a4 = document.getElementById("q4");

    if(a4.value === "8"){
        alert("Du har rett svar på nr 4");
        poeng = poeng + 1;	
	}
	
	var poeng = 0; 
    var a5 = document.getElementById("q55"); 

    if (a5.value === "5") {
        alert("Du har rett svar på nr 5");
        poeng = poeng + 1;
		}
	
	
	var poeng = 0; 
    var a6 = document.getElementById("q6"); 

    if (a6.value === "2015") {
        alert("Du har rett svar på nr 6");
        poeng = poeng + 1;
		}
	
	var poeng = 0; 
    var a7 = document.getElementById("q7"); 

    if (a7.value === "Darth maul") {
        alert("Du har rett svar på nr 7");
        poeng = poeng + 1;
		}
	
	var poeng = 0; 
    var a8 = document.getElementById("q8"); 

    if (a8.value === "Dathomir") {
        alert("Du har rett svar på nr 8");
        poeng = poeng + 1;
		}
	
	var poeng = 0; 
    var a9 = document.getElementById("q9"); 

    if (a9.value === "Sith") {
        alert("Du har rett svar på nr 9");
        poeng = poeng + 1;
		}
	
	var poeng = 0; 
    var a10 = document.getElementById("q10"); 

    if (a10.value === "chancellor palpatine") {
        alert("Du har rett svar på nr 10");
        poeng = poeng + 1;
		}
}

